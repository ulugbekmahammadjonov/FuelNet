import * as React from 'react';
import { styled} from '@mui/material/styles';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import { Avatar, colors, List, ListItem } from '@mui/material';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import InputBase from '@mui/material/InputBase';
import Badge from '@mui/material/Badge';
import MenuItem from '@mui/material/MenuItem';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import BlockIcon from '@mui/icons-material/Block';
import CellTowerIcon from '@mui/icons-material/CellTower';
import Container from './UI/customContainer';
// import Container from '@mui/material/Container';
import { NavLink } from "react-router-dom";
import { nav_link } from '../utils/constants';

import Logo from '../assets/images/logo.svg';
import UserImg from '../assets/images/user.png';
import Button from './UI/button';
const StyledInputBase = styled(InputBase)(({ theme }) => ({
   color: 'inherit',
   '& .MuiInputBase-input': {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create('width'),
      width: '100%',
      [theme.breakpoints.up('md')]: {
         width: '20ch',
      },
   },
}));

export default function Header() {
   const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);
   const [mobileMoreAnchorEl, setMobileMoreAnchorEl] =
      React.useState<null | HTMLElement>(null);

   const isMenuOpen = Boolean(anchorEl);
   const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

   const handleProfileMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
      setAnchorEl(event.currentTarget);
   };

   const handleMobileMenuClose = () => {
      setMobileMoreAnchorEl(null);
   };

   const handleMenuClose = () => {
      setAnchorEl(null);
      handleMobileMenuClose();
   };

   const handleMobileMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
      setMobileMoreAnchorEl(event.currentTarget);
   };

   const menuId = 'primary-search-account-menu';
   const renderMenu = (
      <Menu
         anchorEl={anchorEl}
         anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
         }}
         id={menuId}
         keepMounted
         transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
         }}
         open={isMenuOpen}
         onClose={handleMenuClose}
      >
         <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
         <MenuItem onClick={handleMenuClose}>My account</MenuItem>
      </Menu>
   );

   // const mobileMenuId = 'primary-search-account-menu-mobile';
   // const renderMobileMenu = (
   //    <Menu
   //       anchorEl={mobileMoreAnchorEl}
   //       anchorOrigin={{
   //          vertical: 'top',
   //          horizontal: 'right',
   //       }}
   //       id={mobileMenuId}
   //       keepMounted
   //       transformOrigin={{
   //          vertical: 'top',
   //          horizontal: 'right',
   //       }}
   //       open={isMobileMenuOpen}
   //       onClose={handleMobileMenuClose}
   //    >
   //       <MenuItem>
   //          <IconButton size="large" aria-label="show 4 new mails" color="inherit">
   //             <Badge badgeContent={4} color="error">
   //                <MailIcon />
   //             </Badge>
   //          </IconButton>
   //          <p>Messages</p>
   //       </MenuItem>
   //       <MenuItem>
   //          <IconButton
   //             size="large"
   //             aria-label="show 17 new notifications"
   //             color="inherit"
   //          >
   //             <Badge badgeContent={17} color="error">
   //                <NotificationsIcon />
   //             </Badge>
   //          </IconButton>
   //          <p>Notifications</p>
   //       </MenuItem>
   //       <MenuItem onClick={handleProfileMenuOpen}>
   //          <IconButton
   //             size="large"
   //             aria-label="account of current user"
   //             aria-controls="primary-search-account-menu"
   //             aria-haspopup="true"
   //             color="inherit"
   //          >
   //             <AccountCircle />
   //          </IconButton>
   //          <p>Profile</p>
   //       </MenuItem>
   //    </Menu>
   // );

   return (
      <Box sx={{ flexGrow: 1, borderBottom: '1px solid #E5E5E5', width: '100%', bgcolor: 'white'  }}>
         <Container>

            <AppBar position="static" sx={{ width: '100%', height: '56px', bgcolor: 'secondary.main', boxShadow: 'none' }} >

               <Toolbar disableGutters>
                  <Box component="img" height={'30px'} width={'30px'} src={Logo} sx={{ mr: 2 }} />


                  <Typography
                     variant="h6"
                     noWrap
                     component="div"
                     sx={{ display: {  sm: 'block', color: 'text.primary', fontWeight: 'bold', fontSize: { xs: '14px', md: '20px', lg: '24px'} } }}
                  >
                     FuelNet
                  </Typography>

                  <List sx={{ ml: 2, display: { xs: 'none', md: 'flex' } }}>
                     {nav_link.map(({ id, title, path }) => (

                        <ListItem
                           key={id}

                           component={NavLink}
                           to={path}
                           sx={{ my: 2, display: 'block' }}
                        >
                           <NavLink to={path} className={({ isActive }) => (isActive ? 'active' : "")} style={{ color: title === "Видеофиксация" ? '#FF4E4E' : "#171429", fontWeight: '500', textDecoration: 'none', position: 'relative' }}>{title}{title === "Видеофиксация" && (
                              <Box component={"span"} sx={{

                                 boxShadow: "0px 0px 5px 0px #FF4E4EB2",
                                 marginLeft: '5px',
                                 position: 'absolute',
                                 bottom: '3px',
                                 right: '-10px',
                                 width: '8px',
                                 height: '8px',
                                 backgroundColor: 'error.main',
                                 borderRadius: '50%'
                              }}></Box>
                           )}</NavLink>
                        </ListItem>
                     ))}
                  </List>
                  <Box sx={{ flexGrow: 1 }} />
                  <Box sx={{ display: {  md: 'flex' }, alignItems: 'center', gap: '10px' }}>
                     <Button title='Закрыть смену' icon={<BlockIcon />} sx={{ padding: { xs: '4px 8px', md: '6px 12px' }, bgColor:"#E0F1F6", colorText:"#171429", borderRadius:'100px' }}/>
                     <Button title='Аварийная остановка' icon={<CellTowerIcon />} sx={{ borderRadius: '100px', bgColor: "rgba(255, 78, 78, 0.1)", colorText:"rgba(255, 78, 78)" ,border:'1px solid rgba(255, 78, 78, 0.5)' }} />
                     <IconButton
                        size="large"
                        edge="end"
                        aria-label="account of current user"
                        aria-controls={menuId}
                        aria-haspopup="true"
                        onClick={handleProfileMenuOpen}
                        color="inherit"
                     >
                        <Avatar sx={{ width: 32, height: 32, border: '1px solid #3ABAAA' }} alt="Remy Sharp" src={UserImg} />
                     </IconButton>
                  </Box>
                  {/* <Box sx={{ display: { xs: 'flex', md: 'none' } }}>
                     <IconButton
                        size="large"
                        aria-label="show more"
                        aria-controls={mobileMenuId}
                        aria-haspopup="true"
                        onClick={handleMobileMenuOpen}
                        color="inherit"
                     >
                        <MoreIcon />
                     </IconButton>
                  </Box> */}
               </Toolbar>

            </AppBar>

            {/* {renderMobileMenu}
            {renderMenu} */}

         </Container>
      </Box>
   );
}
