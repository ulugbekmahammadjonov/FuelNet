import React from 'react';
import { Card, CardContent, Typography, Box } from '@mui/material';
import Grid from '@mui/material/Grid';
import AppsIcon from '@mui/icons-material/Apps';
import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import { card_data } from '../utils/constants';
import { column_data } from '../utils/constants';
import Input from './UI/input';
import CustomInputSelect from './UI/input-select';
import Button from './UI/button';

const CustomCard: React.FC = () => {
   const [selectValue, setSelectValue] = React.useState('Полный бак');

   const handleSelectChange = (event: any) => {
      setSelectValue(event.target.value);
   };

   return (
      <Grid container spacing={2} sx={{ minWidth: 275, justifyContent: 'center' }}>
         {column_data.map(({ digit, isActive }) => (
            <Grid
               item
               key={digit}
               xs={12} sm={8} md={6} lg={4}  // responsive grid uchun o'lchamlar
               sx={{ display: 'flex', alignItems: 'stretch' }} // Grid itemlarining to'liq balandlikda bo'lishini ta'minlaydi
            >
               <Card sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between', border: isActive ? '1.5px solid #E9E9E9' : '1.5px solid #FF4E4E', borderRadius: '10px', position: 'relative', height: '100%' }}>
                  <CardContent sx={{ padding: '8px 16px 16px 16px', flexGrow: 1 }}>
                     <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
                        <Typography sx={{ fontWeight: "bold" }}>
                           #{digit}
                        </Typography>
                        <Box
                           sx={{ padding: '6px 12px', color: 'secondary.main', backgroundColor: isActive ? "primary.main" : 'error.main', position: 'absolute', top: "0", left: "0", right: "0", width: "112px", margin: "0 auto", textAlign: "center", borderRadius: "0 0 10px 10px" }}>
                           Подключена
                        </Box>
                        <AppsIcon sx={{ color: 'primary.main' }} />
                     </Box>

                     {/* Temprature, Pressure, and Price */}
                     <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        {card_data.map((data, index) => (
                           <Input key={index} label={data.label} defaultValue={data.value} readOnly={true} padding='10px 16px'width='100px' fontSize='14px' />
                        ))}
                     </Box>

                     {/* Volume and Sum */}
                     <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                        <Input label='Объем (м³)' defaultValue='0.000' readOnly={true} padding='10px 16px' width='150px' fontSize='20px' />
                        <Input label='Сумма (сум)' defaultValue='0.0' readOnly={true} padding='10px 16px' width='150px' fontSize='20px' />
                     </Box>

                     {/* Select and Button */}
                     <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                        <CustomInputSelect />
                     </Box>

                     <Button title='Старт' sx={{ bgColor:'#3ABAAA', borderRadius:'8px', colorText:'#fff',width:'100%', padding:'10px 16px' }}  icon={<PlayCircleOutlineIcon />}  />
                  </CardContent>
               </Card>
            </Grid>
         ))}
      </Grid>
   );
};

export default CustomCard;
