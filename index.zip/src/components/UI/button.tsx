import React from 'react';
import { Button as MuiButton, ButtonProps, Box } from '@mui/material';
import { styled } from '@mui/material/styles';
import { CustomButtonProps } from '../../types/types';


const StyledButton = styled(MuiButton)<CustomButtonProps>(({  title, icon, sx ,...props }) => ({
   
   
   // padding:padding || '6px 12px',
   height: '32px',
   
   textTransform: 'none',
   '&:hover': {
      backgroundColor:  '#1565c0',
   },
   
}));

const Button: React.FC<CustomButtonProps> = ({ sx, title, icon, ...props }) => {
   return (
     <Box sx={sx}>
         {/* <StyledButton
           
            startIcon={icon}
           
            {...props}
         >
            {title}
         </StyledButton> */}
         <Button sx={sx} {...props}>{title}</Button>
     </Box>
   );
};

export default Button;
