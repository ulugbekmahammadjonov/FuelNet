import { Suspense } from 'react'
import { useRoutes } from 'react-router-dom'
import  routes  from './components/config-navigation'
import './App.css'
import Header from './components/header';

function App() {
  const routing = useRoutes(routes);

  return (
   <div>
    <Header />
    
       <Suspense fallback={<div>Loading...</div>}>
        {routing}
      </Suspense>
      
   </div>
  )
}

export default App
