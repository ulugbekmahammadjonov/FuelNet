import React from 'react'

const Volumes = () => {
  return (
    <div>
      Volumes
    </div>
  )
}

export default Volumes
