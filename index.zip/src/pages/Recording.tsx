import React from 'react'


const Recording = () => {
  return (
    <div>
      Recording
      
    </div>
  )
}

export default Recording
